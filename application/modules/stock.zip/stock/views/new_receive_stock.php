 <div class="row">
  <div class="col-lg-12">
    <?php
    $form_attributes = array('id' => 'stock_received_fm','class'=>'form-horizontal','role'=>'form','method'=>'post');
    echo form_open('stock/new_save_received_stock',$form_attributes);?>
  </div>
</div>

<div class="well well-sm"><b>Transaction Details</b></div>
<div class="row">
  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
    <div class="form-group">
      <b>Received From</b>
      <?php $data=array('name' => 'received_from','id'=> 'received_from','class'=>'form-control','value'=>$receipts[0]['issued_by_station_id']); echo form_input($data);?>
    </div>
  </div>
  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
    <div class="form-group">
      <b>S11 #</b>
      <?php $data=array('name' => 's11','id'=> 's11','class'=>'form-control','value'=>$receipts[0]['S11']); echo form_input($data);?>
    </div>
  </div>
  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
    <div class="form-group">
      <b>Date Received</b>
      <?php $data=array('name' => 'date_received','id'=>'date_received','class'=>'form-control'); echo form_input($data);?>
    </div>
  </div> 

  <input type="hidden" name ="transaction_type" class="transaction_type" value="1">
  <?php echo form_hidden('issue_id',$receipts[0]['issue_id']);
        echo form_hidden('order_id',$receipts[0]['order_id']);
        echo form_hidden('date_recorded',date('Y-m-d',strtotime(date('Y-m-d'))));?>
</div>

<br/>
<div class="well well-sm"><b>Vaccine Details</b></div>
<br/>
<div class="table-responsive">


  <div id="stock_receive_tbl">

   <table class="table table-bordered  table-striped" id="rows">
    <thead>
      <th style="width:9%;" class="small">Vaccine/Diluents</th>
      <th style="width:10%;" class="small">Batch No.</th>
      <th style="width:9%;" class="small">Expiry Date</th>
      <th style="width:9%;" class="small">Quantity </br>Ordered</th>
      <th style="width:9%;" class="small">Quantity </br>Received</th>
      <th style="width:12%;" class="small">VVM Status</th>
      <th style="width:9%;" class="small">Comment</th>
   </thead>
   <tbody>
<?php foreach ($vaccines as $vaccine) { ?>
     <tr align="center" value="<?php echo $vaccine['ID'] ?>" id="receive_row<?php echo $vaccine['ID'] ?>" > 
     <td><?php echo $vaccine['Vaccine_name']?></td>
     <input type="hidden" value="<?php echo $vaccine['ID']?>" name="vaccine" id="vaccine">
     <td>
          <select name="batch_no" class="form-control batch_no" id="batch_no" required="true">
                     <option value="">--Select One--</option>
                     
          </select>
     </td>
     <td><?php $data=array('name' => 'expiry_date','id'=> 'expiry_date','class'=>'form-control expiry_date', 'type'=>'date','value'=>'','readonly'=>''); echo form_input($data);?></td>
     <td><?php $data=array('name' => 'quantity_ordered[]','id'=> 'quantity_ordered','class'=>'quantity_ordered form-control','value'=>'','readonly'=>''); echo form_input($data);?></td>
     <td><?php $data=array('name' => 'quantity_received[]','id'=> 'quantity_received','class'=>'quantity_received form-control','value'=>''); echo form_input($data);?></td>
     <td>
      <select name="vvm_status[]" class=" form-control vvm_status " id="vvm_status" name="vvm_status">
        <option value=""> --Select One-- </option>
        <option value="1">Stage 1</option>
        <option value="2">Stage 2</option>
        <option value="3">Stage 3</option>
        <option value="3">Stage 4</option>
      </select></td>
     <td><textarea name="comment[]" id="comment"></textarea></td>      
    </tr>
<?php }?>
  </tbody>
</table>


</div>

<button type="submit" name="stock_received" id="stock_received" class="btn btn-sm btn-danger">Receive Stock</button>

<?php

echo form_close();?>
</div>

<script type="text/javascript">

  $('#date_received').datepicker({dateFormat: "yy-mm-dd",  maxDate: 0}).datepicker('setDate', null);


  $(document).on('ready',function () {
    var receive_row=$('#receive_row');
    var rows = document.getElementById("rows").rows.length;
    var vaccine_rows = rows--;
    var vaccine_array = new Array();
    for (i=1; i < vaccine_rows; i++) { 
      var selected_vaccine = $('#vaccine').val();
      var data = vaccine_array[selected_vaccine];
      console.log(selected_vaccine);
    }
    
               
    batch_details(selected_vaccine);
    });

    function batch_details(selected_vaccine){
      var _url="<?php echo base_url();?>stock/get_order_batch/";
            
        var request=$.ajax({
               url: _url,
               type: 'post',
               data: {"selected_batch":selected_vaccine, "order_id":<?php echo $order_id;?>},

          });
          request.done(function(data){
            data=JSON.parse(data);
            console.log(data);
            var row=$('#receive_row<?php echo $vaccine['ID'] ?>');
            row.closest("tr").find(".expiry_date").val("");
            $.each(data,function(key,value){
            row.closest("tr").find(".batch_no").append("<option value='"+value.batch_no+"'>"+value.batch_no+"</option> ");
              
            });
          });
          request.fail(function(jqXHR, textStatus) {
          
        });
    }

</script>